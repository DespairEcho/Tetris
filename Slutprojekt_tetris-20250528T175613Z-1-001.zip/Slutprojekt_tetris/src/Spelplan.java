
import java.awt.Color;
import java.awt.Graphics;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author viggo.rostmark
 */
public class Spelplan {
    int TILE_SIZE;
    int sizeX;
    int sizeY;

    public Spelplan(int TILE_SIZE, int sizeX, int sizeY) {
        this.TILE_SIZE = TILE_SIZE;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
    }
    
    public void rita(Graphics g) {
        g.setColor(Color.black);
        g.fillRect(0, 0, 300, 600);
        for (int i = 0; i < sizeX; i++) {
            g.setColor(Color.gray);
            g.drawLine(i*TILE_SIZE, 0, i*TILE_SIZE, sizeY*TILE_SIZE);
        }
        for (int i = 0; i < sizeY; i++) {
            g.setColor(Color.gray);
            g.drawLine(0, i*TILE_SIZE, TILE_SIZE*sizeX, i*TILE_SIZE);
        }
    }
}
