
import java.awt.Color;
import static java.awt.Color.white;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.Timer;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
/**
 *
 * @author viggo.rostmark
 */
public class Rityta extends javax.swing.JPanel implements ActionListener {

    /**
     * Creates new form Rityta
     */
    public Rityta() {
        initComponents();
        setFocusable(true);
        /*
        skapaPlan();
        blocks.add(new blocks(TILE_SIZE, 0, 0, 0));
        time.start();
         */
    }

    int TILE_SIZE = 30;
    int sizeX = 10;
    int sizeY = 20;

    Spelplan p = new Spelplan(TILE_SIZE, sizeX, sizeY);
    Block b = new Block(TILE_SIZE, 0, 0, 0);
    ArrayList<Block> blocks = new ArrayList<>();
    ArrayList<FastaBlock> nonMovingBlocks = new ArrayList<>();
    ArrayList<PlanIndex> squares = new ArrayList<>();
    ArrayList<Spelare> leaderboard = new ArrayList<>();
    int rotationsIndex = 0;
    int pause = 0;
    int points = 0;
    boolean checkEnd = false;
    int startTime = 0;
    int lvl = 0;
    int timeDelay = 300;
    boolean isOn = false;
    boolean hasStarted = false;
    Timer time = new Timer(timeDelay, this);

    public void actionPerformed(ActionEvent e) {
        System.out.println(timeDelay);
        if (lvl % 2 == 1) {
            timeDelay -= 100;
            time.setDelay(timeDelay);
        }
        if (startTime > 1) {
            newBlock();
            repaint();
        } else {
            startTime++;
        }

    }

    public void newBlock() {
        if (checkPlanY()) {
            fastBlock();
            setPlanIndex();
            for (int i = 0; i < 4; i++) {
                clearRow();
            }
            setPlanIndex();
            if (checkEnd) {
                endGame();
            }
            points += 4;
            blocks.add(new Block(TILE_SIZE, 0, 0, 0));
            rotationsIndex = 0;
            repaint();
            checkEnd = true;
            return;
        }
        checkEnd = false;
        blocks.get(blocks.size() - 1).flyttaNed();
        repaint();
    }

    public void endGame() {
        time.stop();
        isOn = false;
        hasStarted = false;
        btnPaus.setEnabled(false);
        brnAdd.setEnabled(true);
        System.out.println("end");
    }

    int lk = 0;

    public void clearRow() {
        //Klar
        boolean newLvl = false;
        for (int j = 2; j < 22; j++) {
            int temp = 0;
            for (int i = 1; i <= sizeX; i++) {
                if (i * sizeY - j >= 0) {
                    if (squares.get(i * sizeY - j).index == 1) {
                        temp++;
                        lk = 21 - j;
                    }
                }
            }
            if (temp == sizeX) {
                newLvl = true;
                for (int i = nonMovingBlocks.size(); i >= 1; i--) {
                    if (nonMovingBlocks.get(i - 1).posY == lk) {
                        nonMovingBlocks.remove(i - 1);
                        points += 100;
                    } else if (nonMovingBlocks.get(i - 1).posY < lk) {
                        nonMovingBlocks.get(i - 1).flyttaNed();
                        repaint();
                    } else {
                        repaint();
                    }
                }
            }
        }
    }

    public void setNewLvl() {
        lvl++;

    }

    public void fastBlock() {
        Color temp = blocks.getLast().c;
        int posX = blocks.getLast().posX1;
        int posY = blocks.getLast().posY1;
        nonMovingBlocks.add(new FastaBlock(TILE_SIZE, posX, posY, temp));
        posX = blocks.getLast().posX2;
        posY = blocks.getLast().posY2;
        nonMovingBlocks.add(new FastaBlock(TILE_SIZE, posX, posY, temp));
        posX = blocks.getLast().posX3;
        posY = blocks.getLast().posY3;
        nonMovingBlocks.add(new FastaBlock(TILE_SIZE, posX, posY, temp));
        posX = blocks.getLast().posX4;
        posY = blocks.getLast().posY4;
        nonMovingBlocks.add(new FastaBlock(TILE_SIZE, posX, posY, temp));

        blocks.remove(blocks.size() - 1);

    }

    public boolean checkPlanY() {
        points++;
        if (squares.get((blocks.getLast().posY1) + (blocks.getLast().posX1 * (sizeY))).index == 1) {
            return true;
        }
        if (squares.get((blocks.getLast().posY2) + (blocks.getLast().posX2 * (sizeY))).index == 1) {
            return true;
        }
        if (squares.get((blocks.getLast().posY3) + (blocks.getLast().posX3 * (sizeY))).index == 1) {
            return true;
        }
        if (squares.get((blocks.getLast().posY4) + (blocks.getLast().posX4 * (sizeY))).index == 1) {
            return true;
        }
        return false;
    }

    public void setPlanIndex() {
//        System.out.println(nonMovingBlocks.size() + "");
        skapaPlan();
        for (int i = 0; i < nonMovingBlocks.size(); i++) {
            squares.get((nonMovingBlocks.get(i).posY + (nonMovingBlocks.get(i).posX * sizeY) - 1)).setIndex(1);
        }
    }

    public boolean checkPlanXp() {
        if ((blocks.getLast().posY1 - 1) + ((blocks.getLast().posX1 + 1) * 20) < 200) {
            if (squares.get((blocks.getLast().posY1 - 1) + ((blocks.getLast().posX1 + 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        if ((blocks.getLast().posY2 - 1) + ((blocks.getLast().posX2 + 1) * 20) < 200) {
            if (squares.get((blocks.getLast().posY2 - 1) + ((blocks.getLast().posX2 + 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        if ((blocks.getLast().posY3 - 1) + ((blocks.getLast().posX3 + 1) * 20) < 200) {
            if (squares.get((blocks.getLast().posY3 - 1) + ((blocks.getLast().posX3 + 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        if ((blocks.getLast().posY4 - 1) + ((blocks.getLast().posX4 + 1) * 20) < 200) {
            if (squares.get((blocks.getLast().posY4 - 1) + ((blocks.getLast().posX4 + 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        return false;
    }

    public boolean checkPlanXm() {
        if ((blocks.getLast().posY1 - 1) + ((blocks.getLast().posX1 - 1) * 20) >= 0) {
            if (squares.get((blocks.getLast().posY1 - 1) + ((blocks.getLast().posX1 - 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        if ((blocks.getLast().posY2 - 1) + ((blocks.getLast().posX2 - 1) * 20) >= 0) {
            if (squares.get((blocks.getLast().posY2 - 1) + ((blocks.getLast().posX2 - 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        if ((blocks.getLast().posY3 - 1) + ((blocks.getLast().posX3 - 1) * 20) >= 0) {
            if (squares.get((blocks.getLast().posY3 - 1) + ((blocks.getLast().posX3 - 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        if ((blocks.getLast().posY4 - 1) + ((blocks.getLast().posX4 - 1) * 20) >= 0) {
            if (squares.get((blocks.getLast().posY4 - 1) + ((blocks.getLast().posX4 - 1) * 20)).index == 1) {
                return true;
            }
        } else {
            return true;
        }
        return false;
    }

    public void skapaPlan() {
        squares.clear();
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY - 1; j++) {
                squares.add(new PlanIndex(i, 0));
            }
            squares.add(new PlanIndex(i, 1));
        }

    }

    public ArrayList<Spelare> SortLeaderboard(ArrayList<Spelare> list) {
        ArrayList<Spelare> lista = new ArrayList<>(list);
        for (int i = lista.size(); i > 0; i--) {
            for (int j = 0; j < lista.size() - 1; j++) {
                if (lista.get(j).poäng < lista.get(j + 1).poäng) {
                    Spelare temp = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, temp);
                }
            }
        }
        return lista;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        lblPoints.setText("Points: " + points);
        p.rita(g);
        if(isOn) blocks.getLast().snurra(rotationsIndex);
        for (int i = 0; i < blocks.size(); i++) {
            blocks.get(i).rita(g);
        }
        for (int i = 0; i < nonMovingBlocks.size(); i++) {
            nonMovingBlocks.get(i).ritaRuta(g, nonMovingBlocks.get(i).posX, nonMovingBlocks.get(i).posY);
        }
    }

    private boolean canSnurra(Block b) {
        for (int i : b.positionsY) {
            if (i > 9 || i < 0) {
                return false;
            }

        }
        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txfName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        brnAdd = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaLeaderboard = new javax.swing.JTextArea();
        lblPoints = new javax.swing.JLabel();
        btnStart = new javax.swing.JButton();
        btnPaus = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(500, 600));
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        jLabel1.setText("Name:");

        brnAdd.setText("Add to leaderboard");
        brnAdd.setEnabled(false);
        brnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brnAddActionPerformed(evt);
            }
        });

        txaLeaderboard.setEditable(false);
        txaLeaderboard.setColumns(20);
        txaLeaderboard.setRows(5);
        txaLeaderboard.setPreferredSize(new java.awt.Dimension(200, 100));
        jScrollPane1.setViewportView(txaLeaderboard);

        lblPoints.setText("0");

        btnStart.setText("START");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnPaus.setText("PAUSE");
        btnPaus.setEnabled(false);
        btnPaus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPausActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(324, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnPaus, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(btnStart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblPoints, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txfName)
                    .addComponent(brnAdd, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblPoints, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txfName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(brnAdd)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnPaus, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    public void Pause() {
        if (pause == 0) {
            time.stop();
            pause++;
            isOn = false;
        } else {
            time.start();
            pause = 0;
            isOn = true;
        }
    }

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
            if (hasStarted) {
                Pause();
            }
        }
        if (evt.getKeyCode() == KeyEvent.VK_LEFT) {
            if (isOn) {
                if (checkPlanXm() == false) {
                    blocks.getLast().posX--;
                    repaint();
                }
            }
        }
        if (evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            if (isOn) {
                if (checkPlanXp() == false) {
                    blocks.getLast().posX++;
                    repaint();
                }
            }
        }
        if (evt.getKeyCode() == KeyEvent.VK_DOWN) {

            if (isOn) {
                if (checkPlanY() == false) {
                    newBlock();
                }
            }
        }

        if (evt.getKeyCode() == KeyEvent.VK_UP) {
            if (blocks.getLast().posY > 1) {
                Block activeBlock = blocks.getLast();
                activeBlock.snurra(rotationsIndex+1);
                if (canSnurra(activeBlock)) {
                    rotationsIndex++;
                }

                repaint();
            }
        }


    }//GEN-LAST:event_formKeyPressed


    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        startTime = 0;
        points = 0;
        isOn = true;
        hasStarted = true;
        blocks.clear();
        nonMovingBlocks.clear();
        repaint();
        btnStart.setEnabled(false);
        btnStart.setFocusable(false);
        btnPaus.setEnabled(true);
        skapaPlan();
        blocks.add(new Block(TILE_SIZE, 0, 0, 0));
        time.start();
//        blocks.getLast().snurra(rotationsIndex);
    }//GEN-LAST:event_btnStartActionPerformed


    private void btnPausActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPausActionPerformed
        Pause();
        btnPaus.setFocusable(false);
    }//GEN-LAST:event_btnPausActionPerformed

    private void brnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brnAddActionPerformed
        Spelare s = new Spelare(txfName.getText(), points);
        leaderboard.add(s);
        brnAdd.setEnabled(false);
        txfName.setText("");
        txaLeaderboard.setText("");
        for (int i = 0; i < leaderboard.size(); i++) {
            leaderboard = SortLeaderboard(leaderboard);
            txaLeaderboard.append(leaderboard.get(i).toString());
        }
        txaLeaderboard.setFocusable(false);
        btnStart.setEnabled(true);
    }//GEN-LAST:event_brnAddActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton brnAdd;
    private javax.swing.JButton btnPaus;
    private javax.swing.JButton btnStart;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblPoints;
    private javax.swing.JTextArea txaLeaderboard;
    private javax.swing.JTextField txfName;
    // End of variables declaration//GEN-END:variables
}
