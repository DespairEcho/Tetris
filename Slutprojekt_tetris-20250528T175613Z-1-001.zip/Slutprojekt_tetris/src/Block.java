
import java.awt.Color;
import static java.awt.Color.white;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author viggo.rostmark
 */
public class Block {

    int TILE_SIZE;
    int index;
    Color c;

    int posX,
            posX1,
            posX2,
            posX3,
            posX4,
            posY,
            posY1,
            posY2,
            posY3,
            posY4;
    public int[] positionsX = new int[]{posX1, posX2, posX3, posX4};
    public int[] positionsY = new int[]{posY1, posY2, posY3, posY4};

    public Block(int TILE_SIZE, int index, int posX, int posY) {
        Random r = new Random();
        this.TILE_SIZE = 30;
        this.index = r.nextInt(7);
        this.posX = 5;
        this.posY = 0;
    }

    public void flyttaNed() {
        posY++;
    }

    public void rita(Graphics g) {
        ritaRuta(g, posX1, posY1, c);
        ritaRuta(g, posX2, posY2, c);
        ritaRuta(g, posX3, posY3, c);
        ritaRuta(g, posX4, posY4, c);
    }

    public void snurra(int rotationsIndex) {
        switch (index) {
            case 0:
                switch (rotationsIndex % 4) {
                    case 0:
                        posX1 = posX - 1;
                        posX2 = posX - 2;
                        posX3 = posX - 1;
                        posX4 = posX;

                        posY1 = posY;
                        posY2 = posY;
                        posY3 = posY + 1;
                        posY4 = posY + 1;
                        break;
                    case 1:
                        posX1 = posX;
                        posX2 = posX;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY - 1;
                        posY2 = posY;
                        posY3 = posY;
                        posY4 = posY + 1;
                        break;
                    case 2:
                        posX1 = posX;
                        posX2 = posX - 1;
                        posX3 = posX;
                        posX4 = posX + 1;

                        posY1 = posY;
                        posY2 = posY;
                        posY3 = posY + 1;
                        posY4 = posY + 1;
                        break;
                    case 3:
                        posX1 = posX;
                        posX2 = posX;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 1;
                        posY4 = posY + 2;
                        break;
                }

                c = Color.red;
                break;
            case 1:
                switch (rotationsIndex % 4) {
                    case 0:
                        posX1 = posX - 2;
                        posX2 = posX - 2;
                        posX3 = posX - 1;
                        posX4 = posX;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 1;
                        posY4 = posY + 1;
                        break;
                    case 1:
                        posX1 = posX;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY - 1;
                        posY2 = posY - 1;
                        posY3 = posY;
                        posY4 = posY + 1;
                        break;
                    case 2:
                        posX1 = posX - 2;
                        posX2 = posX - 1;
                        posX3 = posX;
                        posX4 = posX;

                        posY1 = posY;
                        posY2 = posY;
                        posY3 = posY;
                        posY4 = posY + 1;
                        break;
                    case 3:
                        posX1 = posX - 1;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 2;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 2;
                        posY4 = posY + 2;
                        break;
                }

                c = Color.blue;
                break;
            case 2:
                switch (rotationsIndex % 4) {
                    case 0:
                        posX1 = posX - 1;
                        posX2 = posX - 2;
                        posX3 = posX - 1;
                        posX4 = posX;

                        posY1 = posY + 1;
                        posY2 = posY + 1;
                        posY3 = posY;
                        posY4 = posY;
                        break;
                    case 1:
                        posX1 = posX;
                        posX2 = posX;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY + 1;
                        posY2 = posY;
                        posY3 = posY;
                        posY4 = posY - 1;
                        break;
                    case 2:
                        posX1 = posX;
                        posX2 = posX - 1;
                        posX3 = posX;
                        posX4 = posX + 1;

                        posY1 = posY + 1;
                        posY2 = posY + 1;
                        posY3 = posY;
                        posY4 = posY;
                        break;
                    case 3:
                        posX1 = posX;
                        posX2 = posX;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY + 2;
                        posY2 = posY + 1;
                        posY3 = posY + 1;
                        posY4 = posY;
                        break;
                }

                c = Color.green;
                break;
            case 3:
                switch (rotationsIndex % 4) {
                    case 0:
                        posX1 = posX - 1;
                        posX2 = posX - 2;
                        posX3 = posX - 1;
                        posX4 = posX;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 1;
                        posY4 = posY + 1;
                        break;
                    case 1:
                        posX1 = posX;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY;
                        posY2 = posY - 1;
                        posY3 = posY;
                        posY4 = posY + 1;
                        break;
                    case 2:
                        posX1 = posX - 1;
                        posX2 = posX - 2;
                        posX3 = posX - 1;
                        posX4 = posX;

                        posY1 = posY + 1;
                        posY2 = posY;
                        posY3 = posY;
                        posY4 = posY;
                        break;
                    case 3:
                        posX1 = posX - 1;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 2;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 2;
                        posY4 = posY + 1;
                        break;
                }

                c = Color.MAGENTA;
                break;
            case 4:
                posX1 = posX;
                posX2 = posX1 - 1;
                posX3 = posX1 - 1;
                posX4 = posX1;

                posY1 = posY;
                posY2 = posY1;
                posY3 = posY1 + 1;
                posY4 = posY1 + 1;

                c = Color.yellow;
                break;
            case 5:
                switch (rotationsIndex % 4) {
                    case 0:
                        posX1 = posX;
                        posX2 = posX;
                        posX3 = posX - 1;
                        posX4 = posX - 2;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 1;
                        posY4 = posY + 1;
                        break;
                    case 1:
                        posX1 = posX;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY + 2;
                        posY2 = posY;
                        posY3 = posY + 1;
                        posY4 = posY + 2;
                        break;
                    case 2:
                        posX1 = posX - 2;
                        posX2 = posX - 1;
                        posX3 = posX;
                        posX4 = posX - 2;

                        posY1 = posY + 1;
                        posY2 = posY + 1;
                        posY3 = posY + 1;
                        posY4 = posY + 2;
                        break;
                    case 3:
                        posX1 = posX - 1;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 2;

                        posY1 = posY;
                        posY2 = posY + 1;
                        posY3 = posY + 2;
                        posY4 = posY;
                        break;
                }

                c = Color.orange;

                break;
            case 6:
                switch (rotationsIndex % 4) {
                    case 0:
                        posX1 = posX;
                        posX2 = posX + 1;
                        posX3 = posX - 1;
                        posX4 = posX - 2;

                        posY1 = posY;
                        posY2 = posY;
                        posY3 = posY;
                        posY4 = posY;
                        break;
                    case 1:
                        posX1 = posX - 1;
                        posX2 = posX - 1;
                        posX3 = posX - 1;
                        posX4 = posX - 1;

                        posY1 = posY + 1;
                        posY2 = posY;
                        posY3 = posY - 1;
                        posY4 = posY - 2;
                        break;
                    case 2:
                        posX1 = posX;
                        posX2 = posX + 1;
                        posX3 = posX - 1;
                        posX4 = posX - 2;

                        posY1 = posY - 1;
                        posY2 = posY - 1;
                        posY3 = posY - 1;
                        posY4 = posY - 1;
                        break;
                    case 3:
                        posX1 = posX;
                        posX2 = posX;
                        posX3 = posX;
                        posX4 = posX;

                        posY1 = posY + 1;
                        posY2 = posY;
                        posY3 = posY - 1;
                        posY4 = posY - 2;
                        break;

                }

                c = Color.cyan;

                break;
            default:
                throw new AssertionError();
        }
    }
//    public void rita(Graphics g, int rotationsIndex) {
//        switch (index) {
//            case 0:
//                switch (rotationsIndex % 4) {
//                    case 0:
//                        posX1 = posX-1;
//                        posX2 = posX-2;
//                        posX3 = posX-1;
//                        posX4 = posX;
//                
//                        posY1 = posY;
//                        posY2 = posY;
//                        posY3 = posY+1;
//                        posY4 = posY+1;
//                        break;
//                    case 1:
//                        posX1 = posX;
//                        posX2 = posX;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY-1;
//                        posY2 = posY;
//                        posY3 = posY;
//                        posY4 = posY+1;
//                        break;
//                    case 2:
//                        posX1 = posX;
//                        posX2 = posX-1;
//                        posX3 = posX;
//                        posX4 = posX+1;
//                
//                        posY1 = posY;
//                        posY2 = posY;
//                        posY3 = posY+1;
//                        posY4 = posY+1;
//                        break;
//                    case 3:
//                        posX1 = posX;
//                        posX2 = posX;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+1;
//                        posY4 = posY+2;
//                        break;
//                }
//                
//                c = Color.red;
//                
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            case 1:
//                switch (rotationsIndex % 4) {
//                    case 0:
//                        posX1 = posX-2;
//                        posX2 = posX-2;
//                        posX3 = posX-1;
//                        posX4 = posX;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+1;
//                        posY4 = posY+1;
//                        break;
//                    case 1:
//                        posX1 = posX;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY-1;
//                        posY2 = posY-1;
//                        posY3 = posY;
//                        posY4 = posY+1;
//                        break;
//                    case 2:
//                        posX1 = posX-2;
//                        posX2 = posX-1;
//                        posX3 = posX;
//                        posX4 = posX;
//                
//                        posY1 = posY;
//                        posY2 = posY;
//                        posY3 = posY;
//                        posY4 = posY+1;
//                        break;
//                    case 3:
//                        posX1 = posX-1;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-2;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+2;
//                        posY4 = posY+2;
//                        break;
//                }
//                
//                c = Color.blue;
//                
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            case 2:
//                switch (rotationsIndex % 4) {
//                    case 0:
//                        posX1 = posX-1;
//                        posX2 = posX-2;
//                        posX3 = posX-1;
//                        posX4 = posX;
//                
//                        posY1 = posY+1;
//                        posY2 = posY+1;
//                        posY3 = posY;
//                        posY4 = posY;
//                        break;
//                    case 1:
//                        posX1 = posX;
//                        posX2 = posX;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY+1;
//                        posY2 = posY;
//                        posY3 = posY;
//                        posY4 = posY-1;
//                        break;
//                    case 2:
//                        posX1 = posX;
//                        posX2 = posX-1;
//                        posX3 = posX;
//                        posX4 = posX+1;
//                
//                        posY1 = posY+1;
//                        posY2 = posY+1;
//                        posY3 = posY;
//                        posY4 = posY;
//                        break;
//                    case 3:
//                        posX1 = posX;
//                        posX2 = posX;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY+2;
//                        posY2 = posY+1;
//                        posY3 = posY+1;
//                        posY4 = posY;
//                        break;
//                }
//                
//                c = Color.green;
//                
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            case 3:
//                switch (rotationsIndex % 4) {
//                    case 0:
//                        posX1 = posX-1;
//                        posX2 = posX-2;
//                        posX3 = posX-1;
//                        posX4 = posX;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+1;
//                        posY4 = posY+1;
//                        break;
//                    case 1:
//                        posX1 = posX;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY;
//                        posY2 = posY-1;
//                        posY3 = posY;
//                        posY4 = posY+1;
//                        break;
//                    case 2:
//                        posX1 = posX-1;
//                        posX2 = posX-2;
//                        posX3 = posX-1;
//                        posX4 = posX;
//                
//                        posY1 = posY+1;
//                        posY2 = posY;
//                        posY3 = posY;
//                        posY4 = posY;
//                        break;
//                    case 3:
//                        posX1 = posX-1;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-2;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+2;
//                        posY4 = posY+1;
//                        break;
//                }
//                
//                c = Color.MAGENTA;
//                
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            case 4:
//                posX1 = posX;
//                posX2 = posX1-1;
//                posX3 = posX1-1;
//                posX4 = posX1;
//                
//                posY1 = posY;
//                posY2 = posY1;
//                posY3 = posY1+1;
//                posY4 = posY1+1;
//                
//                c = Color.yellow;
//                
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            case 5:
//                switch (rotationsIndex % 4) {
//                    case 0:
//                        posX1 = posX;
//                        posX2 = posX;
//                        posX3 = posX-1;
//                        posX4 = posX-2;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+1;
//                        posY4 = posY+1;
//                        break;
//                    case 1:
//                        posX1 = posX;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY+2;
//                        posY2 = posY;
//                        posY3 = posY+1;
//                        posY4 = posY+2;
//                        break;
//                    case 2:
//                        posX1 = posX-2;
//                        posX2 = posX-1;
//                        posX3 = posX;
//                        posX4 = posX-2;
//                
//                        posY1 = posY+1;
//                        posY2 = posY+1;
//                        posY3 = posY+1;
//                        posY4 = posY+2;
//                        break;
//                    case 3:
//                        posX1 = posX-1;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-2;
//                
//                        posY1 = posY;
//                        posY2 = posY+1;
//                        posY3 = posY+2;
//                        posY4 = posY;
//                        break;
//                }
//                
//                c = Color.orange;
//                
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            case 6:
//                 switch (rotationsIndex % 4) {
//                    case 0:
//                        posX1 = posX;
//                        posX2 = posX+1;
//                        posX3 = posX-1;
//                        posX4 = posX-2;
//                
//                        posY1 = posY;
//                        posY2 = posY;
//                        posY3 = posY;
//                        posY4 = posY;
//                        break;
//                    case 1:
//                        posX1 = posX-1;
//                        posX2 = posX-1;
//                        posX3 = posX-1;
//                        posX4 = posX-1;
//                
//                        posY1 = posY+1;
//                        posY2 = posY;
//                        posY3 = posY-1;
//                        posY4 = posY-2;
//                        break;
//                    case 2:
//                        posX1 = posX;
//                        posX2 = posX+1;
//                        posX3 = posX-1;
//                        posX4 = posX-2;
//                
//                        posY1 = posY-1;
//                        posY2 = posY-1;
//                        posY3 = posY-1;
//                        posY4 = posY-1;
//                        break;
//                    case 3:
//                        posX1 = posX;
//                        posX2 = posX;
//                        posX3 = posX;
//                        posX4 = posX;
//                
//                        posY1 = posY+1;
//                        posY2 = posY;
//                        posY3 = posY-1;
//                        posY4 = posY-2;
//                        break;
//                        
//                }
//                 
//                 c = Color.cyan;
//                 
//                ritaRuta(g, posX1, posY1, c);
//                ritaRuta(g, posX2, posY2, c);
//                ritaRuta(g, posX3, posY3, c);
//                ritaRuta(g, posX4, posY4, c);
//                break;
//            default:
//                throw new AssertionError();
//        }
//    }

    public void ritaRuta(Graphics g, int x, int y, Color c) {
        g.setColor(c);
        g.fillRect(TILE_SIZE * x, TILE_SIZE * y, TILE_SIZE, TILE_SIZE);
        g.setColor(Color.DARK_GRAY);
        g.drawRect(TILE_SIZE * x, TILE_SIZE * y, TILE_SIZE, TILE_SIZE);
    }

    public void setPos(int x, int y) {
        posX = x;
        posY = y;
    }

    @Override
    public String toString() {
        return "Block{" + "TILE_SIZE=" + TILE_SIZE + ", index=" + index + ", posX=" + posX1 + ", posY=" + posY2 + '}';
    }
}
