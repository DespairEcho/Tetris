
import java.awt.Color;
import java.awt.Graphics;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author viggo.rostmark
 */
public class FastaBlock {
    int TILE_SIZE;
    //int index;
    int posX;
    int posY;
    Color c;

    public FastaBlock(int TILE_SIZE, int posX, int posY, Color c) {
        this.TILE_SIZE = TILE_SIZE;
        this.posX = posX;
        this.posY = posY;
        this.c = c;
    }
    
    public void ritaRuta(Graphics g, int x, int y) {
        g.setColor(c);
        g.fillRect(TILE_SIZE*x, TILE_SIZE*y, TILE_SIZE, TILE_SIZE);
        g.setColor(Color.DARK_GRAY);
        g.drawRect(TILE_SIZE*x, TILE_SIZE*y, TILE_SIZE, TILE_SIZE);
    }
    
    public void flyttaNed() {
        posY ++;
//        System.out.println("flytta fasta");
    }
}
