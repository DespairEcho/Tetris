/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author viggo.rostmark
 */
public class PlanIndex {
    int array;
    int index;

    public PlanIndex(int array, int index) {
        this.array = array;
        this.index = index;
    }
    
    public void setIndex(int nyttIndex) {
        index = nyttIndex;
    }

    @Override
    public String toString() {
        return  array + "index=" + index;
    }
}
